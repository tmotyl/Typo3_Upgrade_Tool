<?php
defined('TYPO3') or die();

// Register AJAX routes
$GLOBALS['TYPO3_CONF_VARS']['BE']['toolbarItems'][1648706343] = \TYPO3UpgradeAnalyzer\Backend\ToolbarItems\UpgradeAnalyzerToolbarItem::class;

// Register AJAX handlers
\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::registerAjaxHandler(
    'tx_typo3upgradeanalyzer_collect',
    \TYPO3UpgradeAnalyzer\Controller\AnalyzerController::class . '::collectAction'
);

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::registerAjaxHandler(
    'tx_typo3upgradeanalyzer_export',
    \TYPO3UpgradeAnalyzer\Controller\AnalyzerController::class . '::exportAction'
); 