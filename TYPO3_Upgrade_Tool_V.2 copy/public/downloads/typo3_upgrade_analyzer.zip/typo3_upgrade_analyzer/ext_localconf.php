<?php
defined('TYPO3') or die();

\TYPO3\CMS\Extbase\Utility\ExtensionUtility::configurePlugin(
    'TYPO3UpgradeAnalyzer',
    'SiteData',
    [
        \TYPO3UpgradeAnalyzer\Controller\AnalyzerController::class => 'collect,export',
    ],
    // Non-cacheable actions
    [
        \TYPO3UpgradeAnalyzer\Controller\AnalyzerController::class => 'collect,export',
    ]
);

// Register route enhancer for REST API endpoints
$GLOBALS['TYPO3_CONF_VARS']['SYS']['routing']['enhancers']['UpgradeAnalyzerApi'] = [
    'type' => 'Simple',
    'routePath' => '/typo3-upgrade-analyzer/api',
    'defaults' => [
        'plugin' => 'tx_typo3upgradeanalyzer_sitedata'
    ],
    '_arguments' => [
        'action' => 'action',
    ],
]; 