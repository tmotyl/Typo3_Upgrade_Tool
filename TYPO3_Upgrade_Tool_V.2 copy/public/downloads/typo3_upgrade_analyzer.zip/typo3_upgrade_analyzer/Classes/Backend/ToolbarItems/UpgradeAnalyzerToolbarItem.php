<?php
namespace TYPO3UpgradeAnalyzer\Backend\ToolbarItems;

use TYPO3\CMS\Backend\Toolbar\ToolbarItemInterface;
use TYPO3\CMS\Core\Page\PageRenderer;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Fluid\View\StandaloneView;

/**
 * Toolbar item for the TYPO3 Upgrade Analyzer
 */
class UpgradeAnalyzerToolbarItem implements ToolbarItemInterface
{
    /**
     * Constructor
     */
    public function __construct()
    {
        $pageRenderer = GeneralUtility::makeInstance(PageRenderer::class);
        $pageRenderer->loadRequireJsModule('TYPO3/CMS/TYPO3UpgradeAnalyzer/UpgradeAnalyzerToolbar');
    }

    /**
     * Checks whether the user has access to this toolbar item
     *
     * @return bool TRUE if user has access, FALSE if not
     */
    public function checkAccess(): bool
    {
        return $this->getBackendUser()->isAdmin();
    }

    /**
     * Render toolbar icon
     *
     * @return string HTML
     */
    public function getItem(): string
    {
        $view = $this->getFluidTemplateObject('ToolbarItem.html');
        return $view->render();
    }

    /**
     * This toolbar needs no additional attributes
     *
     * @return array
     */
    public function getAdditionalAttributes(): array
    {
        return [];
    }

    /**
     * This item has a drop down
     *
     * @return bool
     */
    public function hasDropDown(): bool
    {
        return true;
    }

    /**
     * Render drop down
     *
     * @return string HTML
     */
    public function getDropDown(): string
    {
        $view = $this->getFluidTemplateObject('ToolbarItemDropDown.html');
        return $view->render();
    }

    /**
     * No additional JavaScript required for this item
     *
     * @return array
     */
    public function getAdditionalJavaScriptFiles(): array
    {
        return [];
    }

    /**
     * No additional CSS required for this item
     *
     * @return array
     */
    public function getAdditionalCssFiles(): array
    {
        return [];
    }

    /**
     * Returns an instance of the current Backend User
     *
     * @return \TYPO3\CMS\Core\Authentication\BackendUserAuthentication
     */
    protected function getBackendUser()
    {
        return $GLOBALS['BE_USER'];
    }

    /**
     * Returns a new standalone view for the given template
     *
     * @param string $templateName
     * @return StandaloneView
     */
    protected function getFluidTemplateObject(string $templateName): StandaloneView
    {
        $view = GeneralUtility::makeInstance(StandaloneView::class);
        $view->setTemplateRootPaths(['EXT:typo3_upgrade_analyzer/Resources/Private/Templates/ToolbarItems/']);
        $view->setTemplate($templateName);
        return $view;
    }
} 