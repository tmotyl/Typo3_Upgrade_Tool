<?php
namespace TYPO3UpgradeAnalyzer\Controller;

use Psr\Http\Message\ResponseInterface;
use TYPO3\CMS\Core\Core\Environment;
use TYPO3\CMS\Core\Database\ConnectionPool;
use TYPO3\CMS\Core\Http\JsonResponse;
use TYPO3\CMS\Core\Package\PackageManager;
use TYPO3\CMS\Core\Utility\ExtensionManagementUtility;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Core\Utility\VersionNumberUtility;
use TYPO3\CMS\Extbase\Mvc\Controller\ActionController;

/**
 * Controller for collecting site data for upgrade analysis
 */
class AnalyzerController extends ActionController
{
    /**
     * Collect all relevant site data
     *
     * @return ResponseInterface
     */
    public function collectAction(): ResponseInterface
    {
        $siteData = $this->collectSiteData();
        return new JsonResponse($siteData);
    }

    /**
     * Export data as JSON file
     *
     * @return ResponseInterface
     */
    public function exportAction(): ResponseInterface
    {
        $siteData = $this->collectSiteData();
        
        $response = new JsonResponse($siteData);
        $response = $response->withHeader('Content-Disposition', 'attachment; filename="typo3_site_data.json"');
        
        return $response;
    }

    /**
     * Collect all relevant TYPO3 site data
     *
     * @return array
     */
    protected function collectSiteData(): array
    {
        $data = [
            'timestamp' => time(),
            'typo3' => $this->collectTYPO3Data(),
            'extensions' => $this->collectExtensionsData(),
            'database' => $this->collectDatabaseInfo(),
            'system' => $this->collectSystemInfo(),
        ];

        return $data;
    }

    /**
     * Collect TYPO3 core data
     *
     * @return array
     */
    protected function collectTYPO3Data(): array
    {
        $version = VersionNumberUtility::getCurrentTypo3Version();
        
        // Determine if composer-based installation
        $isComposerInstallation = Environment::isComposerMode();
        
        // Determine PHP version
        $phpVersion = PHP_VERSION;
        
        return [
            'version' => $version,
            'composerInstallation' => $isComposerInstallation,
            'phpVersion' => $phpVersion,
        ];
    }

    /**
     * Collect information about installed extensions
     *
     * @return array
     */
    protected function collectExtensionsData(): array
    {
        $extensionData = [];
        $packageManager = GeneralUtility::makeInstance(PackageManager::class);
        $activePackages = $packageManager->getActivePackages();
        
        foreach ($activePackages as $package) {
            // Skip TYPO3 system packages
            if (strpos($package->getPackageKey(), 'typo3/cms-') === 0) {
                continue;
            }
            
            $emConf = [];
            $emConfFile = $package->getPackagePath() . 'ext_emconf.php';
            
            if (file_exists($emConfFile)) {
                $_EXTKEY = $package->getPackageKey();
                include $emConfFile;
                $emConf = $EM_CONF[$_EXTKEY] ?? [];
            }
            
            $composerJson = [];
            $composerJsonFile = $package->getPackagePath() . 'composer.json';
            
            if (file_exists($composerJsonFile)) {
                $composerJson = json_decode(file_get_contents($composerJsonFile), true) ?? [];
            }
            
            $extensionData[] = [
                'key' => $package->getPackageKey(),
                'version' => $emConf['version'] ?? $composerJson['version'] ?? 'unknown',
                'title' => $emConf['title'] ?? $composerJson['description'] ?? $package->getPackageKey(),
                'constraints' => $emConf['constraints'] ?? [],
                'composer' => !empty($composerJson),
                'path' => $package->getPackagePath()
            ];
        }
        
        return $extensionData;
    }

    /**
     * Collect database information
     *
     * @return array
     */
    protected function collectDatabaseInfo(): array
    {
        try {
            $connectionPool = GeneralUtility::makeInstance(ConnectionPool::class);
            $connection = $connectionPool->getConnectionByName(ConnectionPool::DEFAULT_CONNECTION_NAME);
            
            $databasePlatform = $connection->getDatabasePlatform();
            $serverVersion = $connection->getServerVersion();
            
            // Count tables
            $tables = $connection->createSchemaManager()->listTableNames();
            $tableCount = count($tables);
            
            return [
                'type' => $databasePlatform->getName(),
                'version' => $serverVersion,
                'tableCount' => $tableCount,
            ];
        } catch (\Exception $e) {
            return [
                'error' => $e->getMessage()
            ];
        }
    }

    /**
     * Collect system information
     *
     * @return array
     */
    protected function collectSystemInfo(): array
    {
        return [
            'os' => PHP_OS,
            'php' => [
                'version' => PHP_VERSION,
                'sapi' => PHP_SAPI,
                'maxExecutionTime' => ini_get('max_execution_time'),
                'memoryLimit' => ini_get('memory_limit'),
                'extensions' => implode(', ', get_loaded_extensions())
            ],
            'serverSoftware' => $_SERVER['SERVER_SOFTWARE'] ?? 'unknown',
        ];
    }
} 