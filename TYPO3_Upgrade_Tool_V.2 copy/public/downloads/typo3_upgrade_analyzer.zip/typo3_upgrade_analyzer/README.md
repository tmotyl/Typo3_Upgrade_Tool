# TYPO3 Upgrade Analyzer

This extension collects data about your TYPO3 installation to facilitate upgrade planning. It gathers information about:

- Current TYPO3 version and installation type (Composer/non-Composer)
- Installed extensions and their versions
- Database information
- System environment details

## Installation

### Composer Installation

```bash
composer require typo3-upgrade-tool/typo3-upgrade-analyzer
```

Then activate the extension in the Extension Manager.

### Non-Composer Installation

1. Download the extension from the [TYPO3 Extension Repository](https://extensions.typo3.org/) or from [GitHub](https://github.com/typo3-upgrade-tool/typo3-upgrade-analyzer)
2. Upload it to your TYPO3 installation's `typo3conf/ext/` directory
3. Activate the extension in the Extension Manager

## Usage

After installation, a new toolbar item becomes available in the TYPO3 backend toolbar (top-right corner).

### For Administrators:

1. Log in to the TYPO3 backend as an administrator
2. Click on the "Upgrade Analyzer" icon in the top toolbar
3. Choose from the dropdown menu:
   - **Collect Site Data**: Analyze your site and display the results
   - **Download as JSON**: Analyze your site and download the results as a JSON file

### Using with the TYPO3 Upgrade Tool

1. Download the JSON file from your TYPO3 site using the extension
2. Visit [TYPO3 Upgrade Tool](https://example.com/typo3-upgrade-tool)
3. Upload the JSON file in the Analysis tab
4. The tool will automatically analyze your site configuration and recommend upgrade paths

## Security Considerations

- Only administrators can access this extension's functionality
- The extension does not collect any sensitive data like passwords
- No data is sent to external servers - all analysis is performed locally

## Support

If you encounter any issues or have questions, please create an issue on our [GitHub repository](https://github.com/typo3-upgrade-tool/typo3-upgrade-analyzer/issues).

## License

This extension is released under the GPL v2 or later license. 