<?php

$EM_CONF[$_EXTKEY] = [
    'title' => 'TYPO3 Upgrade Analyzer',
    'description' => 'Collects site data for TYPO3 upgrade analysis',
    'category' => 'module',
    'author' => 'TYPO3 Upgrade Tool Team',
    'author_email' => 'info@example.com',
    'state' => 'stable',
    'clearCacheOnLoad' => true,
    'version' => '1.0.0',
    'constraints' => [
        'depends' => [
            'typo3' => '10.4.0-13.4.99',
            'php' => '7.4.0-8.2.99',
        ],
        'conflicts' => [],
        'suggests' => [],
    ],
]; 