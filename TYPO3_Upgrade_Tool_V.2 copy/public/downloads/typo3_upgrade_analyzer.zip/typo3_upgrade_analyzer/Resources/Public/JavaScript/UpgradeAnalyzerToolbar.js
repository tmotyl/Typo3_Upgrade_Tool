/**
 * Module: TYPO3/CMS/TYPO3UpgradeAnalyzer/UpgradeAnalyzerToolbar
 */
define(['jquery', 'TYPO3/CMS/Backend/Notification'], function($, Notification) {
  'use strict';

  /**
   * UpgradeAnalyzerToolbar
   *
   * @type {{}}
   */
  var UpgradeAnalyzerToolbar = {};

  /**
   * Run upgrade analyzer
   */
  UpgradeAnalyzerToolbar.runAnalyzer = function() {
    // Show loading notification
    Notification.info(
      'TYPO3 Upgrade Analyzer',
      'Collecting site data...',
      5
    );

    // Run the analyzer
    $.ajax({
      url: TYPO3.settings.ajaxUrls.tx_typo3upgradeanalyzer_export,
      type: 'GET',
      cache: false,
      success: function(data) {
        // Handle response
        UpgradeAnalyzerToolbar.downloadData(data);
        Notification.success(
          'TYPO3 Upgrade Analyzer',
          'Site data collected successfully!',
          2
        );
      },
      error: function(xhr) {
        console.error(xhr.responseText);
        Notification.error(
          'TYPO3 Upgrade Analyzer',
          'Error collecting site data. Check the browser console for details.',
          0
        );
      }
    });
  };

  /**
   * Download the data as a JSON file
   * 
   * @param {Object} data
   */
  UpgradeAnalyzerToolbar.downloadData = function(data) {
    var dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(data, null, 2));
    var downloadAnchorNode = document.createElement('a');
    downloadAnchorNode.setAttribute("href", dataStr);
    downloadAnchorNode.setAttribute("download", "typo3_site_data.json");
    document.body.appendChild(downloadAnchorNode);
    downloadAnchorNode.click();
    downloadAnchorNode.remove();
  };

  // Initialize: register event handler for toolbar button
  $(document).ready(function() {
    $('.t3js-topbar-button-upgradeanalyzer').on('click', function(e) {
      e.preventDefault();
      UpgradeAnalyzerToolbar.runAnalyzer();
    });
  });

  return UpgradeAnalyzerToolbar;
}); 