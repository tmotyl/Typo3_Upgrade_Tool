<?php

$EMCONF[$_EXTKEY] = [
    'title' => 'Project Export',
    'description' => 'Exports project data as ZIP.',
    'category' => 'module',
    'author' => 'Your Name',
    'author_email' => 'your@email.com',
    'state' => 'beta',
    'clearCacheOnLoad' => 1,
    'version' => '1.0.0',
    'constraints' => [
        'depends' => [
            'typo3' => '11.5.0-11.5.99'
        ],
    ],
];
