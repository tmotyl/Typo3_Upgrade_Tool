<?php

return [
    'dependencies' => [
        'core',
        'backend',
    ],
    'imports' => [
        '@georgringer/news/' => 'EXT:news/Resources/Public/ESM/',
    ],
];
