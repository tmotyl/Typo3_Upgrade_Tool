:template: sitemap.html

=======
Sitemap
=======

.. The sitemap.html template will insert here the page tree automatically.
