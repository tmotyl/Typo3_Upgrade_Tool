.. _tutorialsExternal:

==================
External tutorials
==================

There are already some additional 3rd party tutorials about the extension "news".

Video tutorials by jweiland
^^^^^^^^^^^^^^^^^^^^^^^^^^^

5 german video tutorials by Jochen Weiland which can be found at https://jweiland.net/video-anleitungen/typo3/interessante-typo3-extensions/news-ext.html.

- Installation & Configuration: https://vimeo.com/63231058
- Create an article: https://vimeo.com/63231385
- Output in frontend: https://vimeo.com/63231754
- News archive: https://vimeo.com/63232250
- Multilanguage: https://vimeo.com/63232527


Add links to your own tutorials
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

If you have written an own tutorial or found one which is worth to be mentioned,
please open an issue in the bugtracker.
