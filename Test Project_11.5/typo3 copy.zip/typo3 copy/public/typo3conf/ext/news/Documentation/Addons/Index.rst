.. _addons:

Addons
======

This sections describes extensions which extend EXT:news with additional features.

.. toctree::
   :maxdepth: 3
   :titlesonly:
   :glob:

   NumberedPagination/Index
   NewsAdministration/Index
   NewsSeo/Index
   NewsTagsuggest/Index
   NewsContentElements/Index
   NewsImporticsxml/Index
   NewsCategoryPidConstraint/Index
   NewsRedirectSlugChange/Index
   NewsFegroupPreview/Index
   NewsFilter/Index
