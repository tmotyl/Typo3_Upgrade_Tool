﻿.. _admin-manual:

Administration
==============

This chapter describes how to manage the extension from a superuser point of view.

.. toctree::
   :maxdepth: 2
   :titlesonly:

   Installation/Index
   Configuration/Index
   Update/Index
   Migration/Index
