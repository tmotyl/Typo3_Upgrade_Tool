<?php

namespace Vendor\SystemExport\Command;

use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use TYPO3\CMS\Core\Information\Typo3Version;
use TYPO3\CMS\Core\Utility\VersionNumberUtility;
use TYPO3\CMS\Core\Core\Environment;
use TYPO3\CMS\Core\Package\PackageManager;

class ExportSystemInfoCommand extends Command
{
    protected static $defaultName = 'systemexport:export-system-info';

    protected function configure(): void
    {
        $this->setDescription('Exports TYPO3 system information to a text file.');
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $info = [];

        // TYPO3 version
        $version = new Typo3Version();
        $info[] = 'TYPO3 Version: ' . $version->getVersion();

        // PHP version
        $info[] = 'PHP Version: ' . PHP_VERSION;

        // Database version
        $connection = $GLOBALS['TYPO3_DB'] ?? null;
        if (method_exists($connection, 'getServerVersion')) {
            $info[] = 'Database Version: ' . $connection->getServerVersion();
        } else {
            $info[] = 'Database Version: unknown';
        }

        // Active extensions
        $packageManager = new PackageManager();
        $extensions = $packageManager->getActivePackages();
        $info[] = 'Active Extensions:';
        foreach ($extensions as $key => $package) {
            $info[] = '- ' . $key . ' (' . $package->getPackageMetaData()->getVersion() . ')';
        }

        // Save to file
        $outputFile = Environment::getVarPath() . '/system_info.txt';
        file_put_contents($outputFile, implode(PHP_EOL, $info));

        $output->writeln('<info>System info exported to:</info> ' . $outputFile);

        return Command::SUCCESS;
    }
}
