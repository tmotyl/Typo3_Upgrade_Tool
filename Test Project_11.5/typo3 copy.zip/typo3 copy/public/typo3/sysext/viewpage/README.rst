============================
TYPO3 extension ``viewpage``
============================

Use the (Web>View) backend module to preview a frontend page in the TYPO3 backend.

:Repository:  https://github.com/typo3/typo3
:Issues:      https://forge.typo3.org/
:Read online: https://docs.typo3.org/
:TER:         https://extensions.typo3.org/extension/viewpage/
