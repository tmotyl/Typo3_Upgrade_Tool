============================
TYPO3 extension ``filelist``
============================

This TYPO3 backend module (File>Filelist) is used for managing files.

It makes files in the defined storages available in the backend (upload, delete,
copy etc.). The default storage is fileadmin/.

:Repository:  https://github.com/typo3/typo3
:Issues:      https://forge.typo3.org/
:Read online: https://docs.typo3.org/
:TER:         https://extensions.typo3.org/extension/filelist/
