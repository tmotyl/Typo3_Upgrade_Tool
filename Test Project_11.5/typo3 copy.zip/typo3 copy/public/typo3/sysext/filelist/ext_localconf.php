<?php

declare(strict_types=1);

use TYPO3\CMS\Filelist\ContextMenu\ItemProviders\FileProvider;

defined('TYPO3') or die();

$GLOBALS['TYPO3_CONF_VARS']['BE']['ContextMenu']['ItemProviders'][1486418731] = FileProvider::class;
