#
# Table structure for table 'be_users'
#
CREATE TABLE be_users (
	password_reset_token varchar(100) DEFAULT '' NOT NULL
);
