===========================
TYPO3 extension ``backend``
===========================

This extension includes the TYPO3 backend frame and its basic backend modules,
for example the Login, the Site Configuration, the Pages and the Content module.

:Repository:  https://github.com/typo3/typo3
:Issues:      https://forge.typo3.org/
:Read online: https://docs.typo3.org/
:TER:         https://extensions.typo3.org/extension/backend/
