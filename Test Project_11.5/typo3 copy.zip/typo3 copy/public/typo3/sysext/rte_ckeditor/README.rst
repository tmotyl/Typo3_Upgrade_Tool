================================
TYPO3 extension ``rte_ckeditor``
================================

This extension integrates the `CKEditor`_ as a rich text editor into the TYPO3
backend.

.. _CKEditor: https://ckeditor.com/

:Repository:  https://github.com/typo3/typo3
:Issues:      https://forge.typo3.org/
:Read online: https://docs.typo3.org/c/typo3/cms-rte-ckeditor/11.5/en-us/
:TER:         https://extensions.typo3.org/extension/rte_ckeditor/
