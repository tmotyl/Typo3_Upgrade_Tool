=========================
TYPO3 extension ``fluid``
=========================

This extension integrates the Fluid templating engine into TYPO3.

:Repository:  https://github.com/typo3/typo3
:Issues:      https://forge.typo3.org/
:Read online: https://docs.typo3.org/other/typo3/view-helper-reference/11.5/en-us/
:TER:         https://extensions.typo3.org/extension/fluid/
