========================================
TYPO3 extension ``fluid_styled_content``
========================================

This extension provides Fluid templating for TYPO3 content elements.

:Repository:  https://github.com/typo3/typo3
:Issues:      https://forge.typo3.org/
:Read online: https://docs.typo3.org/c/typo3/cms-fluid-styled-content/11.5/en-us/
:TER:         https://extensions.typo3.org/extension/fluid_styled_content/
