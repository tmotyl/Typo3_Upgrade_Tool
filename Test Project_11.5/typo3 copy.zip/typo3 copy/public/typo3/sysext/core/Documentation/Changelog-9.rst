:orphan:

.. include:: /Includes.rst.txt

============
ChangeLog v9
============

Every change to the TYPO3 Core which might affect your site is documented here.

.. toctree::
   :titlesonly:

   Changelog/9.5.x/Index
   Changelog/9.5/Index
   Changelog/9.4/Index
   Changelog/9.3/Index
   Changelog/9.2/Index
   Changelog/9.1/Index
   Changelog/9.0/Index
