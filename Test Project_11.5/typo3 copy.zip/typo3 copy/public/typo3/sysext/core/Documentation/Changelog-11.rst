:orphan:

.. include:: /Includes.rst.txt

=============
ChangeLog v11
=============

Every change to the TYPO3 Core which might affect your site is documented here.

.. toctree::
   :titlesonly:

   Changelog/11.5.x/Index
   Changelog/11.5/Index
   Changelog/11.4/Index
   Changelog/11.3/Index
   Changelog/11.2/Index
   Changelog/11.1/Index
   Changelog/11.0/Index
