:orphan:

.. include:: /Includes.rst.txt

=============
ChangeLog v10
=============

Every change to the TYPO3 Core which might affect your site is documented here.

.. toctree::
   :titlesonly:

   Changelog/10.4.x/Index
   Changelog/10.4/Index
   Changelog/10.3/Index
   Changelog/10.2/Index
   Changelog/10.1/Index
   Changelog/10.0/Index
