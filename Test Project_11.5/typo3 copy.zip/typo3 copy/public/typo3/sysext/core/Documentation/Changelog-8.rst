:orphan:

.. include:: /Includes.rst.txt

============
ChangeLog v8
============

Every change to the TYPO3 Core which might affect your site is documented here.

.. toctree::
   :titlesonly:

   Changelog/8.7.x/Index
   Changelog/8.7/Index
   Changelog/8.6/Index
   Changelog/8.5/Index
   Changelog/8.4/Index
   Changelog/8.3/Index
   Changelog/8.2/Index
   Changelog/8.1/Index
   Changelog/8.0/Index
