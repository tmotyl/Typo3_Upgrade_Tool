:orphan:

.. include:: /Includes.rst.txt

================
ChangeLog main
================

Every change to the TYPO3 Core which might affect your site is documented here.

.. toctree::
   :titlesonly:

   Changelog/11.5.x/Index
