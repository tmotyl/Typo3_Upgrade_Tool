<?php

$EM_CONF[$_EXTKEY] = [
    'title' => 'TYPO3 Core',
    'description' => 'The core library of TYPO3.',
    'category' => 'be',
    'state' => 'stable',
    'author' => 'TYPO3 Core Team',
    'author_email' => 'typo3cms@typo3.org',
    'author_company' => '',
    'version' => '11.5.41',
    'constraints' => [
        'depends' => [],
        'conflicts' => [],
        'suggests' => [],
    ],
];
