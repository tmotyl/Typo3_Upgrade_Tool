========================
TYPO3 extension ``core``
========================

This extension provides the TYPO3 API, i.e. the core functionalities, which can
be used and extended in any other TYPO3 extension.

:Repository:  https://github.com/typo3/typo3
:Issues:      https://forge.typo3.org/
:Read online: https://docs.typo3.org/
:TER:         https://extensions.typo3.org/extension/core/
