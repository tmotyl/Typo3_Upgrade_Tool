========================
TYPO3 extension ``info``
========================

This TYPO3 backend module displays general information, such as a page tree
overview and localization information.

:Repository:  https://github.com/typo3/typo3
:Issues:      https://forge.typo3.org/
:Read online: https://docs.typo3.org/
:TER:         https://extensions.typo3.org/extension/info/
