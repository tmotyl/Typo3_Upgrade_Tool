==========================
TYPO3 extension ``beuser``
==========================

The TYPO3 backend module System>Backend Users is managing backend users and
groups.

It allows you to add / delete / modify backend users and groups, configure and
compare the settings of backend users and verify their permissions. This module
also displays any backend users who are currently logged in.

:Repository:  https://github.com/typo3/typo3
:Issues:      https://forge.typo3.org/
:Read online: https://docs.typo3.org/
:TER:         https://extensions.typo3.org/extension/beuser/
