=========================
TYPO3 extension ``setup``
=========================

This extension allows users to edit a set of options of their user profile,
including the preferred language, their name and email address.

:Repository:  https://github.com/typo3/typo3
:Issues:      https://forge.typo3.org/
:Read online: https://docs.typo3.org/
:TER:         https://extensions.typo3.org/extension/setup/
