====================================
TYPO3 extension ``extensionmanager``
====================================

The Extension Manager is the backend module for viewing and managing extensions.

:Repository:  https://github.com/typo3/typo3
:Issues:      https://forge.typo3.org/
:Read online: https://docs.typo3.org/
:TER:         https://extensions.typo3.org/extension/extensionmanager/
