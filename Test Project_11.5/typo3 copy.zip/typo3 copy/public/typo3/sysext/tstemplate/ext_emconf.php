<?php

$EM_CONF[$_EXTKEY] = [
    'title' => 'Web>Template',
    'description' => 'Framework for management of TypoScript template records for the CMS frontend.',
    'category' => 'module',
    'state' => 'stable',
    'author' => 'TYPO3 Core Team',
    'author_email' => 'typo3cms@typo3.org',
    'author_company' => '',
    'version' => '11.5.41',
    'constraints' => [
        'depends' => [
            'typo3' => '11.5.41',
        ],
        'conflicts' => [],
        'suggests' => [],
    ],
];
