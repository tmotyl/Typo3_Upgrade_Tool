==============================
TYPO3 extension ``tstemplate``
==============================

This TYPO3 backend module allows the administration of TypoScript templates
that configure the frontend rendering.

:Repository:  https://github.com/typo3/typo3
:Issues:      https://forge.typo3.org/
:Read online: https://docs.typo3.org/
:TER:         https://extensions.typo3.org/extension/tstemplate/
