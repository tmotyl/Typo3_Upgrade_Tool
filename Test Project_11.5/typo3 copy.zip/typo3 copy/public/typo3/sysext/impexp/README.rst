==========================
TYPO3 extension ``impexp``
==========================

This is a tool for importing and exporting records using XML or the custom T3D
format.

:Repository:  https://github.com/typo3/typo3
:Issues:      https://forge.typo3.org/
:Read online: https://docs.typo3.org/c/typo3/cms-impexp/11.5/en-us/
:TER:         https://extensions.typo3.org/extension/impexp/
