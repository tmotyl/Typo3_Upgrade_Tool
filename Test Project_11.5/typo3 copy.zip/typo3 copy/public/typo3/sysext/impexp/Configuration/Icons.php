<?php

return [
    'status-reference-hard' => [
        'provider' => \TYPO3\CMS\Core\Imaging\IconProvider\BitmapIconProvider::class,
        'source' => 'EXT:impexp/Resources/Public/Icons/status-reference-hard.png',
    ],
    'status-reference-soft' => [
        'provider' => \TYPO3\CMS\Core\Imaging\IconProvider\BitmapIconProvider::class,
        'source' => 'EXT:impexp/Resources/Public/Icons/status-reference-soft.png',
    ],
];
