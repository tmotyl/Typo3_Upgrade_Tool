<?php

declare(strict_types=1);

use TYPO3\CMS\Impexp\ContextMenu\ItemProvider;

defined('TYPO3') or die();

$GLOBALS['TYPO3_CONF_VARS']['BE']['ContextMenu']['ItemProviders'][1486418735] = ItemProvider::class;
