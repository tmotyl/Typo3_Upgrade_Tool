============================
TYPO3 extension ``frontend``
============================

This extension covers frontend rendering features, such as TypoScript
configuration or caching, and basic frontend plugins, such as page and content
element rendering.

:Repository:  https://github.com/typo3/typo3
:Issues:      https://forge.typo3.org/
:Read online: https://docs.typo3.org/
:TER:         https://extensions.typo3.org/extension/frontend/
