==============================
TYPO3 extension ``recordlist``
==============================

This extension lists and lets you manage database records in the TYPO3 backend
module (Web>List).

:Repository:  https://github.com/typo3/typo3
:Issues:      https://forge.typo3.org/
:Read online: https://docs.typo3.org/
:TER:         https://extensions.typo3.org/extension/recordlist/
