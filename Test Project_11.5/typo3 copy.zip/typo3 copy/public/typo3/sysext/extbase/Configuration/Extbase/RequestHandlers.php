<?php

declare(strict_types=1);

return [
    \TYPO3\CMS\Extbase\Mvc\Web\FrontendRequestHandler::class,
];
