============================
TYPO3 extension ``sys_note``
============================

This extension allows you to place messages on any page in the TYPO3 backend
that contain instructions or other information about a page or section.

:Repository:  https://github.com/typo3/typo3
:Issues:      https://forge.typo3.org/
:Read online: https://docs.typo3.org/
:TER:         https://extensions.typo3.org/extension/sys_note/
