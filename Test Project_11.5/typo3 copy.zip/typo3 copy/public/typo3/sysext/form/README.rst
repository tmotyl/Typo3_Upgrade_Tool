========================
TYPO3 extension ``form``
========================

This is a flexible TYPO3 frontend form framework that allows editors,
integrators and developers alike to create all kinds of forms.

:Repository:  https://github.com/typo3/typo3
:Issues:      https://forge.typo3.org/
:Read online: https://docs.typo3.org/c/typo3/cms-form/11.5/en-us/
:TER:         https://extensions.typo3.org/extension/form/
