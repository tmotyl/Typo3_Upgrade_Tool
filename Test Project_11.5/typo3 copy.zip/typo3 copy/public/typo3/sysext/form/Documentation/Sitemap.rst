:template: sitemap.html

.. include:: /Includes.rst.txt

=======
Sitemap
=======

.. The sitemap.html template will insert here the page tree automatically.
