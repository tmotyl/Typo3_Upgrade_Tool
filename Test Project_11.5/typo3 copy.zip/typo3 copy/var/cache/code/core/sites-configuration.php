<?php
return array (
  'main' => 
  array (
    'base' => 'https://typo3.ddev.site:33001/',
    'languages' => 
    array (
      0 => 
      array (
        'title' => 'English',
        'enabled' => true,
        'languageId' => 0,
        'base' => '/',
        'typo3Language' => 'default',
        'locale' => 'en_US.UTF-8',
        'iso-639-1' => 'en',
        'navigationTitle' => 'English',
        'hreflang' => 'en-us',
        'direction' => 'ltr',
        'flag' => 'us',
      ),
    ),
    'rootPageId' => 1,
    'websiteTitle' => '',
  ),
);
#