<?php

class Export_action_index_af8b5f4fa63cb41a58414a95432ad4418fa54c2c extends \TYPO3Fluid\Fluid\Core\Compiler\AbstractCompiledTemplate {

public function getLayoutName(\TYPO3Fluid\Fluid\Core\Rendering\RenderingContextInterface $renderingContext) {
$self = $this;
return (string) 'Default';
}
public function hasLayout() {
return TRUE;
}
public function addCompiledNamespaces(\TYPO3Fluid\Fluid\Core\Rendering\RenderingContextInterface $renderingContext) {
$renderingContext->getViewHelperResolver()->addNamespaces(array (
  'core' => 
  array (
    0 => 'TYPO3\\CMS\\Core\\ViewHelpers',
  ),
  'f' => 
  array (
    0 => 'TYPO3Fluid\\Fluid\\ViewHelpers',
    1 => 'TYPO3\\CMS\\Fluid\\ViewHelpers',
  ),
  'formvh' => 
  array (
    0 => 'TYPO3\\CMS\\Form\\ViewHelpers',
  ),
));
}

/**
 * section content
 */
public function section_040f06fd774092478d450774f5ba30c5da78acc8(\TYPO3Fluid\Fluid\Core\Rendering\RenderingContextInterface $renderingContext) {
$self = $this;
$output0 = '';

$output0 .= '
    <div class="export-container">
        <div class="main-card">
            <div class="card-header">
                <div class="header-content">
                    <div class="header-icon">
                        <span class="t3-icon t3-icon-apps-pagetree-folder-default t3-icon-size-medium"></span>
                    </div>
                    <div class="header-text">
                        <h1 class="card-title">';
$array1 = array (
);
$output0 .= call_user_func_array( function ($var) { return (is_string($var) || (is_object($var) && method_exists($var, '__toString')) ? htmlspecialchars((string) $var, ENT_QUOTES) : $var); }, [$renderingContext->getVariableProvider()->getByPath('message', $array1)]);

$output0 .= '</h1>
                        <p class="card-subtitle">Eksport informacji o projekcie TYPO3</p>
                    </div>
                </div>
            </div>
            
            <div class="card-body">
                <div class="content-grid">
                    <!-- Informacje o module -->
                    <div class="info-section">
                        <div class="info-card">
                            <div class="info-header">
                                <span class="t3-icon t3-icon-actions-system-extension-download t3-icon-size-default"></span>
                                <h3>Funkcjonalności eksportu</h3>
                            </div>
                            <div class="info-content">
                                <p class="description">
                                    Ten moduł pozwala na eksport informacji o projekcie TYPO3 w formacie JSON.
                                </p>
                                
                                <div class="feature-list">
                                    <h4>Eksportowane dane obejmują:</h4>
                                    <div class="features-grid">
                                        <div class="feature-item">
                                            <span class="feature-icon t3-icon t3-icon-status-dialog-information"></span>
                                            <span>Wersję TYPO3</span>
                                        </div>
                                        <div class="feature-item">
                                            <span class="feature-icon t3-icon t3-icon-status-dialog-information"></span>
                                            <span>Wersję PHP</span>
                                        </div>
                                        <div class="feature-item">
                                            <span class="feature-icon t3-icon t3-icon-status-dialog-information"></span>
                                            <span>Listę zainstalowanych rozszerzeń</span>
                                        </div>
                                        <div class="feature-item">
                                            <span class="feature-icon t3-icon t3-icon-status-dialog-information"></span>
                                            <span>Znacznik czasu eksportu</span>
                                        </div>
                                        <div class="feature-item">
                                            <span class="feature-icon t3-icon t3-icon-status-dialog-information"></span>
                                            <span>Informację o użytkowniku eksportującym</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Sekcja eksportu -->
                    <div class="export-section">
                        <div class="export-card">
                            <div class="export-header">
                                <div class="export-icon">
                                    <span class="t3-icon t3-icon-actions-download t3-icon-size-large"></span>
                                </div>
                                <h3>Eksportuj dane</h3>
                                <p class="export-description">
                                    Pobierz plik JSON z informacjami o projekcie
                                </p>
                            </div>
                            
                            <div class="export-action">
                                ';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\FormViewHelper
$renderChildrenClosure3 = function() use ($renderingContext, $self) {
$output4 = '';

$output4 .= '
                                    ';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Form\SubmitViewHelper
$renderChildrenClosure6 = function() use ($renderingContext, $self) {
return NULL;
};
$arguments5 = array();
$arguments5['additionalAttributes'] = NULL;
$arguments5['data'] = NULL;
$arguments5['aria'] = NULL;
$arguments5['name'] = NULL;
$arguments5['value'] = NULL;
$arguments5['property'] = NULL;
$arguments5['disabled'] = NULL;
$arguments5['class'] = NULL;
$arguments5['dir'] = NULL;
$arguments5['id'] = NULL;
$arguments5['lang'] = NULL;
$arguments5['style'] = NULL;
$arguments5['title'] = NULL;
$arguments5['accesskey'] = NULL;
$arguments5['tabindex'] = NULL;
$arguments5['onclick'] = NULL;
$arguments5['value'] = 'Eksportuj dane projektu';
$arguments5['class'] = 'btn-export';
// Rendering Array
$array7 = array();
$array7['title'] = 'Kliknij aby pobrać plik JSON z danymi projektu';
$arguments5['additionalAttributes'] = $array7;

$output4 .= TYPO3\CMS\Fluid\ViewHelpers\Form\SubmitViewHelper::renderStatic($arguments5, $renderChildrenClosure6, $renderingContext);

$output4 .= '
                                ';
return $output4;
};
$arguments2 = array();
$arguments2['additionalAttributes'] = NULL;
$arguments2['data'] = NULL;
$arguments2['aria'] = NULL;
$arguments2['action'] = NULL;
$arguments2['arguments'] = array (
);
$arguments2['controller'] = NULL;
$arguments2['extensionName'] = NULL;
$arguments2['pluginName'] = NULL;
$arguments2['pageUid'] = NULL;
$arguments2['object'] = NULL;
$arguments2['pageType'] = 0;
$arguments2['noCache'] = false;
$arguments2['section'] = '';
$arguments2['format'] = '';
$arguments2['additionalParams'] = array (
);
$arguments2['absolute'] = false;
$arguments2['addQueryString'] = false;
$arguments2['argumentsToBeExcludedFromQueryString'] = array (
);
$arguments2['addQueryStringMethod'] = NULL;
$arguments2['fieldNamePrefix'] = NULL;
$arguments2['actionUri'] = NULL;
$arguments2['objectName'] = NULL;
$arguments2['hiddenFieldClassName'] = NULL;
$arguments2['enctype'] = NULL;
$arguments2['method'] = NULL;
$arguments2['name'] = NULL;
$arguments2['onreset'] = NULL;
$arguments2['onsubmit'] = NULL;
$arguments2['target'] = NULL;
$arguments2['novalidate'] = NULL;
$arguments2['class'] = NULL;
$arguments2['dir'] = NULL;
$arguments2['id'] = NULL;
$arguments2['lang'] = NULL;
$arguments2['style'] = NULL;
$arguments2['title'] = NULL;
$arguments2['accesskey'] = NULL;
$arguments2['tabindex'] = NULL;
$arguments2['onclick'] = NULL;
$arguments2['action'] = 'export';
$arguments2['method'] = 'post';
$arguments2['controller'] = 'Export';
$arguments2['class'] = 'export-form';

$output0 .= TYPO3\CMS\Fluid\ViewHelpers\FormViewHelper::renderStatic($arguments2, $renderChildrenClosure3, $renderingContext);

$output0 .= '
                                
                                <div class="format-info">
                                    <div class="format-item">
                                        <span class="t3-icon t3-icon-mimetypes-application-json"></span>
                                        <span>Format: JSON</span>
                                    </div>
                                    <div class="format-item">
                                        <span class="t3-icon t3-icon-actions-system-extension-configure"></span>
                                        <span>Kodowanie: UTF-8</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Uwagi i informacje -->
                <div class="notes-section">
                    <div class="warning-card">
                        <div class="warning-header">
                            <span class="t3-icon t3-icon-status-dialog-warning t3-icon-size-default"></span>
                            <h4>Uwagi dotyczące eksportu</h4>
                        </div>
                        <div class="warning-content">
                            <div class="warning-items">
                                <div class="warning-item">
                                    <span class="t3-icon t3-icon-status-user-admin"></span>
                                    <span>Eksport wymaga uprawnień administratora backend</span>
                                </div>
                                <div class="warning-item">
                                    <span class="t3-icon t3-icon-actions-download"></span>
                                    <span>Plik zostanie automatycznie pobrany po kliknięciu przycisku</span>
                                </div>
                                <div class="warning-item">
                                    <span class="t3-icon t3-icon-actions-system-refresh"></span>
                                    <span>Dane są generowane w czasie rzeczywistym</span>
                                </div>
                                <div class="warning-item">
                                    <span class="t3-icon t3-icon-status-dialog-ok"></span>
                                    <span>Nie są eksportowane żadne dane wrażliwe ani hasła</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="card-footer">
                <div class="footer-content">
                    <div class="footer-info">
                        <span class="t3-icon t3-icon-actions-system-extension-documentation"></span>
                        <span>Moduł eksportu projektu TYPO3</span>
                    </div>
                    <div class="footer-version">
                        <span>Wersja: 1.0.0</span>
                    </div>
                    <div class="footer-time">
                        <span class="t3-icon t3-icon-actions-system-clock"></span>
                        ';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$renderChildrenClosure9 = function() use ($renderingContext, $self) {
$output10 = '';
// Rendering ViewHelper TYPO3Fluid\Fluid\ViewHelpers\VariableViewHelper
$renderChildrenClosure12 = function() use ($renderingContext, $self) {
return NULL;
};
$arguments11 = array();
$arguments11['value'] = NULL;
$arguments11['name'] = NULL;
$arguments11['name'] = 'currentTime';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$renderChildrenClosure14 = function() use ($renderingContext, $self) {
return NULL;
};
$arguments13 = array();
$arguments13['date'] = NULL;
$arguments13['format'] = '';
$arguments13['base'] = NULL;
$arguments13['date'] = 'now';
$renderChildrenClosure14 = ($arguments13['date'] !== null) ? function() use ($arguments13) { return $arguments13['date']; } : $renderChildrenClosure14;$arguments11['value'] = TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper::renderStatic($arguments13, $renderChildrenClosure14, $renderingContext);
$renderChildrenClosure12 = ($arguments11['value'] !== null) ? function() use ($arguments11) { return $arguments11['value']; } : $renderChildrenClosure12;
$output10 .= TYPO3Fluid\Fluid\ViewHelpers\VariableViewHelper::renderStatic($arguments11, $renderChildrenClosure12, $renderingContext);
$array15 = array (
);
$output10 .= $renderingContext->getVariableProvider()->getByPath('currentTime', $array15);
return $output10;
};
$arguments8 = array();
$arguments8['date'] = NULL;
$arguments8['format'] = '';
$arguments8['base'] = NULL;
$arguments8['format'] = 'd.m.Y H:i:s';
$renderChildrenClosure9 = ($arguments8['date'] !== null) ? function() use ($arguments8) { return $arguments8['date']; } : $renderChildrenClosure9;
$output0 .= call_user_func_array( function ($var) { return (is_string($var) || (is_object($var) && method_exists($var, '__toString')) ? htmlspecialchars((string) $var, ENT_QUOTES) : $var); }, [TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper::renderStatic($arguments8, $renderChildrenClosure9, $renderingContext)]);

$output0 .= '
                    </div>
                </div>
            </div>
        </div>
    </div>

    <style>
        /* Główne zmienne kolorystyczne TYPO3 */
        :root {
            --typo3-orange: #ff8700;
            --typo3-orange-dark: #e6790a;
            --typo3-orange-light: #ffb366;
            --typo3-gray-dark: #2d3748;
            --typo3-gray-medium: #4a5568;
            --typo3-gray-light: #a0aec0;
            --typo3-gray-lightest: #f7fafc;
            --typo3-blue: #007acc;
            --typo3-blue-dark: #005a99;
            --typo3-green: #00b894;
            --typo3-red: #e17055;
            --typo3-yellow: #fdcb6e;
            --typo3-white: #ffffff;
            --typo3-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            --typo3-shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
        }

        /* Reset i podstawowe style */
        * {
            box-sizing: border-box;
        }

        .export-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 2rem;
            font-family: \'Source Sans Pro\', -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, sans-serif;
            background: linear-gradient(135deg, var(--typo3-gray-lightest) 0%, #edf2f7 100%);
            min-height: 100vh;
        }

        /* Główna karta */
        .main-card {
            background: var(--typo3-white);
            border-radius: 12px;
            box-shadow: var(--typo3-shadow-lg);
            overflow: hidden;
            border: 1px solid #e2e8f0;
        }

        /* Header karty */
        .card-header {
            background: linear-gradient(135deg, var(--typo3-orange) 0%, var(--typo3-orange-dark) 100%);
            color: var(--typo3-white);
            padding: 2rem;
        }

        .header-content {
            display: flex;
            align-items: center;
            gap: 1.5rem;
        }

        .header-icon {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 64px;
            height: 64px;
            background: rgba(255, 255, 255, 0.2);
            border-radius: 50%;
            backdrop-filter: blur(10px);
        }

        .header-text .card-title {
            margin: 0 0 0.5rem 0;
            font-size: 2rem;
            font-weight: 700;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
        }

        .header-text .card-subtitle {
            margin: 0;
            font-size: 1.1rem;
            opacity: 0.9;
            font-weight: 300;
        }

        /* Zawartość karty */
        .card-body {
            padding: 2.5rem;
        }

        .content-grid {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 2.5rem;
            margin-bottom: 2.5rem;
        }

        /* Sekcja informacji */
        .info-card {
            background: var(--typo3-white);
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            padding: 2rem;
            box-shadow: var(--typo3-shadow);
        }

        .info-header {
            display: flex;
            align-items: center;
            gap: 1rem;
            margin-bottom: 1.5rem;
            padding-bottom: 1rem;
            border-bottom: 2px solid var(--typo3-orange-light);
        }

        .info-header h3 {
            margin: 0;
            color: var(--typo3-gray-dark);
            font-size: 1.5rem;
            font-weight: 600;
        }

        .description {
            font-size: 1.1rem;
            line-height: 1.6;
            color: var(--typo3-gray-medium);
            margin-bottom: 1.5rem;
        }

        .feature-list h4 {
            color: var(--typo3-gray-dark);
            font-size: 1.2rem;
            font-weight: 600;
            margin-bottom: 1rem;
        }

        .features-grid {
            display: grid;
            gap: 0.75rem;
        }

        .feature-item {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            padding: 0.75rem;
            background: #f8fafc;
            border-radius: 6px;
            border-left: 3px solid var(--typo3-orange);
            transition: all 0.2s ease;
        }

        .feature-item:hover {
            background: #edf2f7;
            transform: translateX(4px);
        }

        .feature-icon {
            color: var(--typo3-orange);
            flex-shrink: 0;
        }

        /* Sekcja eksportu */
        .export-card {
            background: linear-gradient(135deg, var(--typo3-blue) 0%, var(--typo3-blue-dark) 100%);
            color: var(--typo3-white);
            border-radius: 12px;
            padding: 2rem;
            text-align: center;
            box-shadow: var(--typo3-shadow-lg);
            position: relative;
            overflow: hidden;
        }

        .export-card::before {
            content: \'\';
            position: absolute;
            top: -50%;
            right: -50%;
            width: 100%;
            height: 100%;
            background: radial-gradient(circle, rgba(255, 255, 255, 0.1) 0%, transparent 70%);
            pointer-events: none;
        }

        .export-header {
            position: relative;
            z-index: 1;
            margin-bottom: 2rem;
        }

        .export-icon {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 80px;
            height: 80px;
            background: rgba(255, 255, 255, 0.15);
            border-radius: 50%;
            margin-bottom: 1rem;
            backdrop-filter: blur(10px);
        }

        .export-header h3 {
            margin: 0 0 0.5rem 0;
            font-size: 1.5rem;
            font-weight: 600;
        }

        .export-description {
            margin: 0;
            opacity: 0.9;
            font-size: 1rem;
        }

        .export-action {
            position: relative;
            z-index: 1;
        }

        .export-form {
            margin-bottom: 1.5rem;
        }

        .btn-export {
            background: var(--typo3-orange);
            color: var(--typo3-white);
            border: none;
            padding: 1rem 2rem;
            font-size: 1.1rem;
            font-weight: 600;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 4px 12px rgba(255, 135, 0, 0.3);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .btn-export:hover {
            background: var(--typo3-orange-dark);
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(255, 135, 0, 0.4);
        }

        .btn-export:active {
            transform: translateY(0);
        }

        .format-info {
            display: flex;
            justify-content: center;
            gap: 2rem;
            flex-wrap: wrap;
        }

        .format-item {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 0.9rem;
            opacity: 0.9;
        }

        /* Sekcja uwag */
        .notes-section {
            margin-top: 2.5rem;
        }

        .warning-card {
            background: linear-gradient(135deg, #fff5f5 0%, #fed7d7 100%);
            border: 1px solid #feb2b2;
            border-radius: 8px;
            padding: 2rem;
            box-shadow: var(--typo3-shadow);
        }

        .warning-header {
            display: flex;
            align-items: center;
            gap: 1rem;
            margin-bottom: 1.5rem;
            padding-bottom: 1rem;
            border-bottom: 2px solid var(--typo3-red);
        }

        .warning-header h4 {
            margin: 0;
            color: var(--typo3-red);
            font-size: 1.3rem;
            font-weight: 600;
        }

        .warning-items {
            display: grid;
            gap: 1rem;
        }

        .warning-item {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 1rem;
            background: var(--typo3-white);
            border-radius: 6px;
            border-left: 3px solid var(--typo3-red);
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
        }

        .warning-item span:first-child {
            color: var(--typo3-red);
            flex-shrink: 0;
        }

        /* Footer */
        .card-footer {
            background: #f8fafc;
            border-top: 1px solid #e2e8f0;
            padding: 1.5rem 2.5rem;
        }

        .footer-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 1rem;
            font-size: 0.9rem;
            color: var(--typo3-gray-medium);
        }

        .footer-info,
        .footer-version,
        .footer-time {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        /* Responsywność */
        @media (max-width: 768px) {
            .export-container {
                padding: 1rem;
            }

            .content-grid {
                grid-template-columns: 1fr;
                gap: 1.5rem;
            }

            .header-content {
                flex-direction: column;
                text-align: center;
                gap: 1rem;
            }

            .header-text .card-title {
                font-size: 1.5rem;
            }

            .card-body {
                padding: 1.5rem;
            }

            .format-info {
                flex-direction: column;
                gap: 1rem;
            }

            .footer-content {
                flex-direction: column;
                text-align: center;
            }
        }

        @media (max-width: 480px) {
            .info-card, .export-card {
                padding: 1.5rem;
            }

            .btn-export {
                width: 100%;
                padding: 1rem;
            }
        }

        /* Animacje */
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .main-card {
            animation: fadeInUp 0.6s ease-out;
        }

        .info-card,
        .export-card,
        .warning-card {
            animation: fadeInUp 0.6s ease-out;
            animation-fill-mode: both;
        }

        .info-card {
            animation-delay: 0.1s;
        }

        .export-card {
            animation-delay: 0.2s;
        }

        .warning-card {
            animation-delay: 0.3s;
        }
    </style>
';

return $output0;
}
/**
 * Main Render function
 */
public function render(\TYPO3Fluid\Fluid\Core\Rendering\RenderingContextInterface $renderingContext) {
$self = $this;
$output16 = '';
// Rendering ViewHelper TYPO3Fluid\Fluid\ViewHelpers\LayoutViewHelper
$renderChildrenClosure18 = function() use ($renderingContext, $self) {
return NULL;
};
$arguments17 = array();
$arguments17['name'] = NULL;
$arguments17['name'] = 'Default';

$output16 .= call_user_func_array( function ($var) { return (is_string($var) || (is_object($var) && method_exists($var, '__toString')) ? htmlspecialchars((string) $var, ENT_QUOTES) : $var); }, ['']);

$output16 .= '

';
// Rendering ViewHelper TYPO3Fluid\Fluid\ViewHelpers\SectionViewHelper
$renderChildrenClosure20 = function() use ($renderingContext, $self) {
$output21 = '';

$output21 .= '
    <div class="export-container">
        <div class="main-card">
            <div class="card-header">
                <div class="header-content">
                    <div class="header-icon">
                        <span class="t3-icon t3-icon-apps-pagetree-folder-default t3-icon-size-medium"></span>
                    </div>
                    <div class="header-text">
                        <h1 class="card-title">';
$array22 = array (
);
$output21 .= call_user_func_array( function ($var) { return (is_string($var) || (is_object($var) && method_exists($var, '__toString')) ? htmlspecialchars((string) $var, ENT_QUOTES) : $var); }, [$renderingContext->getVariableProvider()->getByPath('message', $array22)]);

$output21 .= '</h1>
                        <p class="card-subtitle">Eksport informacji o projekcie TYPO3</p>
                    </div>
                </div>
            </div>
            
            <div class="card-body">
                <div class="content-grid">
                    <!-- Informacje o module -->
                    <div class="info-section">
                        <div class="info-card">
                            <div class="info-header">
                                <span class="t3-icon t3-icon-actions-system-extension-download t3-icon-size-default"></span>
                                <h3>Funkcjonalności eksportu</h3>
                            </div>
                            <div class="info-content">
                                <p class="description">
                                    Ten moduł pozwala na eksport informacji o projekcie TYPO3 w formacie JSON.
                                </p>
                                
                                <div class="feature-list">
                                    <h4>Eksportowane dane obejmują:</h4>
                                    <div class="features-grid">
                                        <div class="feature-item">
                                            <span class="feature-icon t3-icon t3-icon-status-dialog-information"></span>
                                            <span>Wersję TYPO3</span>
                                        </div>
                                        <div class="feature-item">
                                            <span class="feature-icon t3-icon t3-icon-status-dialog-information"></span>
                                            <span>Wersję PHP</span>
                                        </div>
                                        <div class="feature-item">
                                            <span class="feature-icon t3-icon t3-icon-status-dialog-information"></span>
                                            <span>Listę zainstalowanych rozszerzeń</span>
                                        </div>
                                        <div class="feature-item">
                                            <span class="feature-icon t3-icon t3-icon-status-dialog-information"></span>
                                            <span>Znacznik czasu eksportu</span>
                                        </div>
                                        <div class="feature-item">
                                            <span class="feature-icon t3-icon t3-icon-status-dialog-information"></span>
                                            <span>Informację o użytkowniku eksportującym</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Sekcja eksportu -->
                    <div class="export-section">
                        <div class="export-card">
                            <div class="export-header">
                                <div class="export-icon">
                                    <span class="t3-icon t3-icon-actions-download t3-icon-size-large"></span>
                                </div>
                                <h3>Eksportuj dane</h3>
                                <p class="export-description">
                                    Pobierz plik JSON z informacjami o projekcie
                                </p>
                            </div>
                            
                            <div class="export-action">
                                ';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\FormViewHelper
$renderChildrenClosure24 = function() use ($renderingContext, $self) {
$output25 = '';

$output25 .= '
                                    ';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Form\SubmitViewHelper
$renderChildrenClosure27 = function() use ($renderingContext, $self) {
return NULL;
};
$arguments26 = array();
$arguments26['additionalAttributes'] = NULL;
$arguments26['data'] = NULL;
$arguments26['aria'] = NULL;
$arguments26['name'] = NULL;
$arguments26['value'] = NULL;
$arguments26['property'] = NULL;
$arguments26['disabled'] = NULL;
$arguments26['class'] = NULL;
$arguments26['dir'] = NULL;
$arguments26['id'] = NULL;
$arguments26['lang'] = NULL;
$arguments26['style'] = NULL;
$arguments26['title'] = NULL;
$arguments26['accesskey'] = NULL;
$arguments26['tabindex'] = NULL;
$arguments26['onclick'] = NULL;
$arguments26['value'] = 'Eksportuj dane projektu';
$arguments26['class'] = 'btn-export';
// Rendering Array
$array28 = array();
$array28['title'] = 'Kliknij aby pobrać plik JSON z danymi projektu';
$arguments26['additionalAttributes'] = $array28;

$output25 .= TYPO3\CMS\Fluid\ViewHelpers\Form\SubmitViewHelper::renderStatic($arguments26, $renderChildrenClosure27, $renderingContext);

$output25 .= '
                                ';
return $output25;
};
$arguments23 = array();
$arguments23['additionalAttributes'] = NULL;
$arguments23['data'] = NULL;
$arguments23['aria'] = NULL;
$arguments23['action'] = NULL;
$arguments23['arguments'] = array (
);
$arguments23['controller'] = NULL;
$arguments23['extensionName'] = NULL;
$arguments23['pluginName'] = NULL;
$arguments23['pageUid'] = NULL;
$arguments23['object'] = NULL;
$arguments23['pageType'] = 0;
$arguments23['noCache'] = false;
$arguments23['section'] = '';
$arguments23['format'] = '';
$arguments23['additionalParams'] = array (
);
$arguments23['absolute'] = false;
$arguments23['addQueryString'] = false;
$arguments23['argumentsToBeExcludedFromQueryString'] = array (
);
$arguments23['addQueryStringMethod'] = NULL;
$arguments23['fieldNamePrefix'] = NULL;
$arguments23['actionUri'] = NULL;
$arguments23['objectName'] = NULL;
$arguments23['hiddenFieldClassName'] = NULL;
$arguments23['enctype'] = NULL;
$arguments23['method'] = NULL;
$arguments23['name'] = NULL;
$arguments23['onreset'] = NULL;
$arguments23['onsubmit'] = NULL;
$arguments23['target'] = NULL;
$arguments23['novalidate'] = NULL;
$arguments23['class'] = NULL;
$arguments23['dir'] = NULL;
$arguments23['id'] = NULL;
$arguments23['lang'] = NULL;
$arguments23['style'] = NULL;
$arguments23['title'] = NULL;
$arguments23['accesskey'] = NULL;
$arguments23['tabindex'] = NULL;
$arguments23['onclick'] = NULL;
$arguments23['action'] = 'export';
$arguments23['method'] = 'post';
$arguments23['controller'] = 'Export';
$arguments23['class'] = 'export-form';

$output21 .= TYPO3\CMS\Fluid\ViewHelpers\FormViewHelper::renderStatic($arguments23, $renderChildrenClosure24, $renderingContext);

$output21 .= '
                                
                                <div class="format-info">
                                    <div class="format-item">
                                        <span class="t3-icon t3-icon-mimetypes-application-json"></span>
                                        <span>Format: JSON</span>
                                    </div>
                                    <div class="format-item">
                                        <span class="t3-icon t3-icon-actions-system-extension-configure"></span>
                                        <span>Kodowanie: UTF-8</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Uwagi i informacje -->
                <div class="notes-section">
                    <div class="warning-card">
                        <div class="warning-header">
                            <span class="t3-icon t3-icon-status-dialog-warning t3-icon-size-default"></span>
                            <h4>Uwagi dotyczące eksportu</h4>
                        </div>
                        <div class="warning-content">
                            <div class="warning-items">
                                <div class="warning-item">
                                    <span class="t3-icon t3-icon-status-user-admin"></span>
                                    <span>Eksport wymaga uprawnień administratora backend</span>
                                </div>
                                <div class="warning-item">
                                    <span class="t3-icon t3-icon-actions-download"></span>
                                    <span>Plik zostanie automatycznie pobrany po kliknięciu przycisku</span>
                                </div>
                                <div class="warning-item">
                                    <span class="t3-icon t3-icon-actions-system-refresh"></span>
                                    <span>Dane są generowane w czasie rzeczywistym</span>
                                </div>
                                <div class="warning-item">
                                    <span class="t3-icon t3-icon-status-dialog-ok"></span>
                                    <span>Nie są eksportowane żadne dane wrażliwe ani hasła</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="card-footer">
                <div class="footer-content">
                    <div class="footer-info">
                        <span class="t3-icon t3-icon-actions-system-extension-documentation"></span>
                        <span>Moduł eksportu projektu TYPO3</span>
                    </div>
                    <div class="footer-version">
                        <span>Wersja: 1.0.0</span>
                    </div>
                    <div class="footer-time">
                        <span class="t3-icon t3-icon-actions-system-clock"></span>
                        ';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$renderChildrenClosure30 = function() use ($renderingContext, $self) {
$output31 = '';
// Rendering ViewHelper TYPO3Fluid\Fluid\ViewHelpers\VariableViewHelper
$renderChildrenClosure33 = function() use ($renderingContext, $self) {
return NULL;
};
$arguments32 = array();
$arguments32['value'] = NULL;
$arguments32['name'] = NULL;
$arguments32['name'] = 'currentTime';
// Rendering ViewHelper TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper
$renderChildrenClosure35 = function() use ($renderingContext, $self) {
return NULL;
};
$arguments34 = array();
$arguments34['date'] = NULL;
$arguments34['format'] = '';
$arguments34['base'] = NULL;
$arguments34['date'] = 'now';
$renderChildrenClosure35 = ($arguments34['date'] !== null) ? function() use ($arguments34) { return $arguments34['date']; } : $renderChildrenClosure35;$arguments32['value'] = TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper::renderStatic($arguments34, $renderChildrenClosure35, $renderingContext);
$renderChildrenClosure33 = ($arguments32['value'] !== null) ? function() use ($arguments32) { return $arguments32['value']; } : $renderChildrenClosure33;
$output31 .= TYPO3Fluid\Fluid\ViewHelpers\VariableViewHelper::renderStatic($arguments32, $renderChildrenClosure33, $renderingContext);
$array36 = array (
);
$output31 .= $renderingContext->getVariableProvider()->getByPath('currentTime', $array36);
return $output31;
};
$arguments29 = array();
$arguments29['date'] = NULL;
$arguments29['format'] = '';
$arguments29['base'] = NULL;
$arguments29['format'] = 'd.m.Y H:i:s';
$renderChildrenClosure30 = ($arguments29['date'] !== null) ? function() use ($arguments29) { return $arguments29['date']; } : $renderChildrenClosure30;
$output21 .= call_user_func_array( function ($var) { return (is_string($var) || (is_object($var) && method_exists($var, '__toString')) ? htmlspecialchars((string) $var, ENT_QUOTES) : $var); }, [TYPO3\CMS\Fluid\ViewHelpers\Format\DateViewHelper::renderStatic($arguments29, $renderChildrenClosure30, $renderingContext)]);

$output21 .= '
                    </div>
                </div>
            </div>
        </div>
    </div>

    <style>
        /* Główne zmienne kolorystyczne TYPO3 */
        :root {
            --typo3-orange: #ff8700;
            --typo3-orange-dark: #e6790a;
            --typo3-orange-light: #ffb366;
            --typo3-gray-dark: #2d3748;
            --typo3-gray-medium: #4a5568;
            --typo3-gray-light: #a0aec0;
            --typo3-gray-lightest: #f7fafc;
            --typo3-blue: #007acc;
            --typo3-blue-dark: #005a99;
            --typo3-green: #00b894;
            --typo3-red: #e17055;
            --typo3-yellow: #fdcb6e;
            --typo3-white: #ffffff;
            --typo3-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            --typo3-shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
        }

        /* Reset i podstawowe style */
        * {
            box-sizing: border-box;
        }

        .export-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 2rem;
            font-family: \'Source Sans Pro\', -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, sans-serif;
            background: linear-gradient(135deg, var(--typo3-gray-lightest) 0%, #edf2f7 100%);
            min-height: 100vh;
        }

        /* Główna karta */
        .main-card {
            background: var(--typo3-white);
            border-radius: 12px;
            box-shadow: var(--typo3-shadow-lg);
            overflow: hidden;
            border: 1px solid #e2e8f0;
        }

        /* Header karty */
        .card-header {
            background: linear-gradient(135deg, var(--typo3-orange) 0%, var(--typo3-orange-dark) 100%);
            color: var(--typo3-white);
            padding: 2rem;
        }

        .header-content {
            display: flex;
            align-items: center;
            gap: 1.5rem;
        }

        .header-icon {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 64px;
            height: 64px;
            background: rgba(255, 255, 255, 0.2);
            border-radius: 50%;
            backdrop-filter: blur(10px);
        }

        .header-text .card-title {
            margin: 0 0 0.5rem 0;
            font-size: 2rem;
            font-weight: 700;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
        }

        .header-text .card-subtitle {
            margin: 0;
            font-size: 1.1rem;
            opacity: 0.9;
            font-weight: 300;
        }

        /* Zawartość karty */
        .card-body {
            padding: 2.5rem;
        }

        .content-grid {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 2.5rem;
            margin-bottom: 2.5rem;
        }

        /* Sekcja informacji */
        .info-card {
            background: var(--typo3-white);
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            padding: 2rem;
            box-shadow: var(--typo3-shadow);
        }

        .info-header {
            display: flex;
            align-items: center;
            gap: 1rem;
            margin-bottom: 1.5rem;
            padding-bottom: 1rem;
            border-bottom: 2px solid var(--typo3-orange-light);
        }

        .info-header h3 {
            margin: 0;
            color: var(--typo3-gray-dark);
            font-size: 1.5rem;
            font-weight: 600;
        }

        .description {
            font-size: 1.1rem;
            line-height: 1.6;
            color: var(--typo3-gray-medium);
            margin-bottom: 1.5rem;
        }

        .feature-list h4 {
            color: var(--typo3-gray-dark);
            font-size: 1.2rem;
            font-weight: 600;
            margin-bottom: 1rem;
        }

        .features-grid {
            display: grid;
            gap: 0.75rem;
        }

        .feature-item {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            padding: 0.75rem;
            background: #f8fafc;
            border-radius: 6px;
            border-left: 3px solid var(--typo3-orange);
            transition: all 0.2s ease;
        }

        .feature-item:hover {
            background: #edf2f7;
            transform: translateX(4px);
        }

        .feature-icon {
            color: var(--typo3-orange);
            flex-shrink: 0;
        }

        /* Sekcja eksportu */
        .export-card {
            background: linear-gradient(135deg, var(--typo3-blue) 0%, var(--typo3-blue-dark) 100%);
            color: var(--typo3-white);
            border-radius: 12px;
            padding: 2rem;
            text-align: center;
            box-shadow: var(--typo3-shadow-lg);
            position: relative;
            overflow: hidden;
        }

        .export-card::before {
            content: \'\';
            position: absolute;
            top: -50%;
            right: -50%;
            width: 100%;
            height: 100%;
            background: radial-gradient(circle, rgba(255, 255, 255, 0.1) 0%, transparent 70%);
            pointer-events: none;
        }

        .export-header {
            position: relative;
            z-index: 1;
            margin-bottom: 2rem;
        }

        .export-icon {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 80px;
            height: 80px;
            background: rgba(255, 255, 255, 0.15);
            border-radius: 50%;
            margin-bottom: 1rem;
            backdrop-filter: blur(10px);
        }

        .export-header h3 {
            margin: 0 0 0.5rem 0;
            font-size: 1.5rem;
            font-weight: 600;
        }

        .export-description {
            margin: 0;
            opacity: 0.9;
            font-size: 1rem;
        }

        .export-action {
            position: relative;
            z-index: 1;
        }

        .export-form {
            margin-bottom: 1.5rem;
        }

        .btn-export {
            background: var(--typo3-orange);
            color: var(--typo3-white);
            border: none;
            padding: 1rem 2rem;
            font-size: 1.1rem;
            font-weight: 600;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 4px 12px rgba(255, 135, 0, 0.3);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .btn-export:hover {
            background: var(--typo3-orange-dark);
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(255, 135, 0, 0.4);
        }

        .btn-export:active {
            transform: translateY(0);
        }

        .format-info {
            display: flex;
            justify-content: center;
            gap: 2rem;
            flex-wrap: wrap;
        }

        .format-item {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 0.9rem;
            opacity: 0.9;
        }

        /* Sekcja uwag */
        .notes-section {
            margin-top: 2.5rem;
        }

        .warning-card {
            background: linear-gradient(135deg, #fff5f5 0%, #fed7d7 100%);
            border: 1px solid #feb2b2;
            border-radius: 8px;
            padding: 2rem;
            box-shadow: var(--typo3-shadow);
        }

        .warning-header {
            display: flex;
            align-items: center;
            gap: 1rem;
            margin-bottom: 1.5rem;
            padding-bottom: 1rem;
            border-bottom: 2px solid var(--typo3-red);
        }

        .warning-header h4 {
            margin: 0;
            color: var(--typo3-red);
            font-size: 1.3rem;
            font-weight: 600;
        }

        .warning-items {
            display: grid;
            gap: 1rem;
        }

        .warning-item {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 1rem;
            background: var(--typo3-white);
            border-radius: 6px;
            border-left: 3px solid var(--typo3-red);
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
        }

        .warning-item span:first-child {
            color: var(--typo3-red);
            flex-shrink: 0;
        }

        /* Footer */
        .card-footer {
            background: #f8fafc;
            border-top: 1px solid #e2e8f0;
            padding: 1.5rem 2.5rem;
        }

        .footer-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 1rem;
            font-size: 0.9rem;
            color: var(--typo3-gray-medium);
        }

        .footer-info,
        .footer-version,
        .footer-time {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        /* Responsywność */
        @media (max-width: 768px) {
            .export-container {
                padding: 1rem;
            }

            .content-grid {
                grid-template-columns: 1fr;
                gap: 1.5rem;
            }

            .header-content {
                flex-direction: column;
                text-align: center;
                gap: 1rem;
            }

            .header-text .card-title {
                font-size: 1.5rem;
            }

            .card-body {
                padding: 1.5rem;
            }

            .format-info {
                flex-direction: column;
                gap: 1rem;
            }

            .footer-content {
                flex-direction: column;
                text-align: center;
            }
        }

        @media (max-width: 480px) {
            .info-card, .export-card {
                padding: 1.5rem;
            }

            .btn-export {
                width: 100%;
                padding: 1rem;
            }
        }

        /* Animacje */
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .main-card {
            animation: fadeInUp 0.6s ease-out;
        }

        .info-card,
        .export-card,
        .warning-card {
            animation: fadeInUp 0.6s ease-out;
            animation-fill-mode: both;
        }

        .info-card {
            animation-delay: 0.1s;
        }

        .export-card {
            animation-delay: 0.2s;
        }

        .warning-card {
            animation-delay: 0.3s;
        }
    </style>
';
return $output21;
};
$arguments19 = array();
$arguments19['name'] = NULL;
$arguments19['name'] = 'content';

$output16 .= '';

return $output16;
}


}
#